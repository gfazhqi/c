import a24_0x3ee4ab from "chalk";
import { createSessionDirectory, getAllFilesFromFolder, getSessionDirectory, getUserFromUrl, readJsonFile, runtimeServer, updateBanner, writeToFile } from "./app/utils/helper.js";
import { DIR_PATH_SESSION } from "./app/utils/konst.js";
import a24_0x55c58f from "./app/form.js";
import a24_0x3c824c from "./app/deleteAccount.js";
import a24_0x574679 from "./app/mainMenu.js";
import a24_0x585eed from "./app/startBot.js";
import a24_0x5b1bf0 from "./app/libs/catizen.js";

createSessionDirectory(DIR_PATH_SESSION);

(async () => {
  let _0x2cff5a = await runtimeServer();
  if (_0x2cff5a.status === "exit") {
    process.stdout.write(updateBanner(_0x2cff5a.baner));
    process.exit();
  }
  
  let _0xbe590f = 0;
  while (_0x2cff5a.status === "reconnecting") {
    _0xbe590f++;
    process.stdout.write("c");
    process.stdout.write(updateBanner(_0x2cff5a.baner));
    console.log(a24_0x3ee4ab.yellowBright("Reconnecting ") + a24_0x3ee4ab.whiteBright("•".repeat(_0xbe590f)));
    if (_0xbe590f > 4) {
      _0xbe590f = 0;
    }
    _0x2cff5a = await runtimeServer();
    await new Promise(_0x442dd2 => setTimeout(_0x442dd2, 5000));
  }
  
  process.stdout.write("c");
  process.stdout.write(updateBanner(_0x2cff5a.baner));
  process.stdout.write("c");

  while (true) {
    const _0x2dffc7 = await a24_0x574679(_0x2cff5a.baner);
    if (_0x2dffc7 === "exit") {
      process.exit();
    }

    if (_0x2dffc7 === "1") {
      var _0x3948db = getAllFilesFromFolder(DIR_PATH_SESSION);
      let _0x3783db = [];
      for (let _0x4125bc = 0; _0x4125bc < _0x3948db.length; _0x4125bc++) {
        let _0x38f579 = _0x3948db[_0x4125bc];
        if (_0x38f579) {
          var _0x447d17 = readJsonFile(_0x38f579);
          _0x3783db.push(_0x447d17);
        }
      }

      if (_0x3948db.length < 1) {
        await a24_0x55c58f(a24_0x3ee4ab.yellowBright("Account is empty, please add account before start bot") + "\n" + a24_0x3ee4ab.blackBright("Press Enter To Back"), _0x2cff5a.baner);
      } else {
        const _0x240bf4 = await a24_0x585eed(_0x3783db, _0x2cff5a.baner);
        if (_0x240bf4 === "exit") {
          process.exit();
        }
      }
    }

    if (_0x2dffc7 === "2") {
      const _0xe2533b = await a24_0x55c58f("Enter your init_data", _0x2cff5a.baner);
      let _0x3bd006;
      try {
        _0x3bd006 = getUserFromUrl(_0xe2533b);
      } catch (_0x5760a1) {
        await a24_0x55c58f(a24_0x3ee4ab.yellowBright("WTF with your input, Check your input moron!") + "\n" + a24_0x3ee4ab.blackBright("Press Enter To Back"), _0x2cff5a.baner);
        continue;
      }

      let _0x7f0231 = {
        use_proxy: false,
        proxy_hostname: "",
        proxy_protocol: "socks5",
        proxy_port: 0,
        proxy_username: "",
        proxy_password: ""
      };

      const _0x5371eb = new a24_0x5b1bf0({
        token: "",
        initData: _0xe2533b
      });

      const _0x3ea878 = await _0x5371eb.login();
      if ("code" in _0x3ea878) {
        if (_0x3ea878.code === 106) {
          await a24_0x55c58f(a24_0x3ee4ab.redBright("Catizen on Maintenance") + "\n" + a24_0x3ee4ab.blackBright("Press Enter To Back"), _0x2cff5a.baner);
        }
        if (_0x3ea878.code === 2) {
          await a24_0x55c58f(a24_0x3ee4ab.redBright("Invalid Credentials, Please Recapture Credentials") + "\n" + a24_0x3ee4ab.blackBright("Press Enter To Back"), _0x2cff5a.baner);
        }
      } else {
        try {
          writeToFile(getSessionDirectory(DIR_PATH_SESSION) + "/" + _0x3bd006.username + ".json", JSON.stringify({
            username: _0x3bd006.username,
            access_token: "",
            init_data: _0xe2533b,
            ..._0x7f0231
          }));
          await a24_0x55c58f(a24_0x3ee4ab.greenBright("Success To Add Login") + "\n" + a24_0x3ee4ab.blackBright("Press Enter To Back"), _0x2cff5a.baner);
        } catch (_0x3bdbca) {
          await a24_0x55c58f(a24_0x3ee4ab.redBright("Something went wrong") + "\n" + a24_0x3ee4ab.blackBright("Press Enter To Back"), _0x2cff5a.baner);
          continue;
        }
      }
    }

    if (_0x2dffc7 === "3") {
      try {
        var _0x3948db = getAllFilesFromFolder(DIR_PATH_SESSION);
        let _0x441589 = [];
        for (let _0x1b1d75 = 0; _0x1b1d75 < _0x3948db.length; _0x1b1d75++) {
          let _0x43d8bd = _0x3948db[_0x1b1d75];
          if (_0x43d8bd) {
            var _0x447d17 = readJsonFile(_0x43d8bd);
            _0x441589.push({
              name: _0x447d17.username,
              location: _0x43d8bd
            });
          }
        }

        if (_0x441589.length > 0) {
          const _0x37437b = await a24_0x3c824c(_0x441589, _0x2cff5a.baner);
          if (_0x37437b === "exit") {
            process.exit();
          }
        } else {
          await a24_0x55c58f(a24_0x3ee4ab.redBright("Account is empty") + "\n" + a24_0x3ee4ab.blackBright("Press Enter To Back"), _0x2cff5a.baner);
          continue;
        }
      } catch (_0x4b2421) {
        await a24_0x55c58f(a24_0x3ee4ab.redBright("Something went wrong") + "\n" + a24_0x3ee4ab.blackBright("Press Enter To Back"), _0x2cff5a.baner);
        continue;
      }
    }
  }
})();
